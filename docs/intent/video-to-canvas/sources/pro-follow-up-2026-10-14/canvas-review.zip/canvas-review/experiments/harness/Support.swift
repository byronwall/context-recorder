// Linux test support only. No AVFoundation/CoreGraphics/Vision execution.
// GrayImage.halved follows FrameSource.swift; image methods below are metadata stubs.
import Foundation
public struct GrayImage: Sendable {
    public let width: Int
    public let height: Int
    public var pixels: [UInt8]
    public init(width: Int, height: Int, pixels: [UInt8]) {
        precondition(pixels.count == width * height)
        self.width = width; self.height = height; self.pixels = pixels
    }
    public func halved() -> GrayImage {
        let w = width / 2, h = height / 2
        var out = [UInt8](repeating: 0, count: w * h)
        pixels.withUnsafeBufferPointer { src in
            out.withUnsafeMutableBufferPointer { dst in
                for y in 0..<h {
                    let r0 = (2 * y) * width, r1 = r0 + width, o = y * w
                    for x in 0..<w {
                        let s = Int(src[r0 + 2 * x]) + Int(src[r0 + 2 * x + 1]) + Int(src[r1 + 2 * x]) + Int(src[r1 + 2 * x + 1])
                        dst[o + x] = UInt8(s >> 2)
                    }
                }
            }
        }
        return GrayImage(width: w, height: h, pixels: out)
    }
}
public struct FrameRef: Sendable { public var index: Int; public var time: Double }
public struct CGImage { public var width: Int; public var height: Int }
public final class DecodedFrame: @unchecked Sendable {
    public let ref: FrameRef
    public let gray: GrayImage
    public let small: GrayImage
    init(ref: FrameRef, gray: GrayImage) { self.ref = ref; self.gray = gray; self.small = gray.halved() }
    public func colorImage() -> CGImage? { CGImage(width: gray.width, height: gray.height) }
    public func colorRows(_ y0: Int, _ y1: Int) -> CGImage? {
        guard y0 >= 0, y1 <= gray.height, y1 > y0 else { return nil }
        return CGImage(width: gray.width, height: y1-y0)
    }
}
struct CanvasItem { enum Reason: String { case start, change, motion, noOverlap = "no-overlap", ambiguous, heightLimit = "height-limit" } }
public struct CanvasError: Error { var message: String; public init(_ message: String) { self.message = message } }
