"""Candidate estimators and narrow ablations. NOT an integrated replacement pipeline.
Geometry candidates do not certify same-state content, provenance, or a safe stitch.
"""
from pathlib import Path
import json
import numpy as np
import cv2
ROOT=Path(__file__).resolve().parent
DATA=ROOT/'generated'
input=json.loads((DATA/'input.json').read_text())

def image(s):return np.frombuffer((ROOT/s['path']).read_bytes(),np.uint8).reshape((s['height'],s['width']))

def phase(a,b):
    h,w=a.shape
    hann=cv2.createHanningWindow((w,h),cv2.CV_32F)
    (dx,dy),response=cv2.phaseCorrelate(a.astype(np.float32),b.astype(np.float32),hann)
    return {'dx':float(dx),'scrollY':float(-dy),'response':float(response)}

def tile_candidates(a,b):
    h,w=a.shape; votes=[]
    for row in range(3):
        for col in range(3):
            y0,y1=row*h//3,(row+1)*h//3; x0,x1=col*w//3,(col+1)*w//3
            aa,bb=a[y0:y1,x0:x1],b[y0:y1,x0:x1]
            if aa.std()<3 or bb.std()<3:continue
            p=phase(aa,bb)
            if not(np.isfinite(p['dx']) and np.isfinite(p['scrollY'])) or p['response']<.15:continue
            votes.append({**p,'tile':[col,row]})
    clusters=[]
    for v in votes:
        # A proposal is corroborated by tile coordinates, not just a global best score.
        near=[x for x in votes if abs(x['dx']-v['dx'])<1 and abs(x['scrollY']-v['scrollY'])<1]
        if len(near)<3 or len({x['tile'][1] for x in near})<2:continue
        dx=float(np.median([x['dx'] for x in near]));dy=float(np.median([x['scrollY'] for x in near]))
        if any(abs(dx-x['dx'])<1 and abs(dy-x['scrollY'])<1 for x in clusters):continue
        clusters.append({'dx':dx,'scrollY':dy,'supportTiles':len(near),'tiles':[x['tile'] for x in near]})
    return sorted(clusters,key=lambda x:-x['supportTiles'])

def sparse_candidates(a,b):
    points=cv2.goodFeaturesToTrack(a,maxCorners=600,qualityLevel=.015,minDistance=6,blockSize=5)
    if points is None:return []
    nxt,ok,err=cv2.calcOpticalFlowPyrLK(a,b,points,None,winSize=(21,21),maxLevel=3,
                                     criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,40,.001))
    if nxt is None:return []
    back,okb,_=cv2.calcOpticalFlowPyrLK(b,a,nxt,None,winSize=(21,21),maxLevel=3,
                                     criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,40,.001))
    good=(ok[:,0]>0)&(okb[:,0]>0)&(np.linalg.norm(back-points,axis=2)[:,0]<.5)&(err[:,0]<20)
    p=points[:,0][good]; delta=(nxt-points)[:,0][good]
    clusters=[]
    for v in delta:
        near=np.linalg.norm(delta-v,axis=1)<.6
        if near.sum()<8:continue
        med=np.median(delta[near],axis=0)
        if any(np.linalg.norm(med-np.array([x['dx'],-x['scrollY']]))<.6 for x in clusters):continue
        ys=p[near,1];xs=p[near,0]
        clusters.append({'dx':float(med[0]),'scrollY':float(-med[1]),'points':int(near.sum()),
                         'supportBounds':[float(xs.min()),float(ys.min()),float(xs.max()),float(ys.max())]})
    return sorted(clusters,key=lambda x:-x['points'])

results=[]
for pair in input['pairs']:
    a,b=image(pair['a']),image(pair['b'])
    out={'id':pair['id'],'wholeImagePhase':phase(a,b),'tilePhaseCandidates':tile_candidates(a,b),
         'sparseFlowCandidates':sparse_candidates(a,b),'status':'candidate generation only; not a safe-join verdict'}
    if 'knownCols' in pair:
        x0,x1=pair['knownCols'];out['oracleRegionPhase']=phase(a[:,x0:x1],b[:,x0:x1])
    results.append(out)
    print(pair['id'],'tile',[(round(x['dx'],2),round(x['scrollY'],2),x['supportTiles']) for x in out['tilePhaseCandidates']],
          'flow',[(round(x['dx'],2),round(x['scrollY'],2),x['points']) for x in out['sparseFlowCandidates'][:3]])
(ROOT.parent/'results'/'prototype-results.json').write_text(json.dumps({'opencv':cv2.__version__,'pairs':results},indent=2)+'\n')
# A sampling/anchor ablation, using native integer-shift code on every second slow frame.
# Preserves original frame indices/times, unlike the deliberately geometric-only overlay-skip oracle.
slow=next(x for x in input['sequences'] if x['id']=='slow-half-pixel')
input2={'pairs':[],'sequences':[{'id':'slow-even-frames-anchor-ablation','frames':slow['frames'][::2]}]}
(DATA/'anchor-input.json').write_text(json.dumps(input2,indent=2)+'\n')
