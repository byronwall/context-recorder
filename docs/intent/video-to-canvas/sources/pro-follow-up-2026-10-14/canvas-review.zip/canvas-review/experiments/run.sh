#!/usr/bin/env bash
# Run only in this disposable experiment directory. No repository, app, or personal session is modified.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p ../results
printf '\n[1/6] Verify pinned upstream source and prepare platform-isolated Swift files\n'
python3 prepare_swift.py
printf '\n[2/6] Compile the actual Swift row matcher, verifier, and segmenter with metadata stubs\n'
swiftc -O build/*.swift harness/Support.swift harness/main.swift -o build/core-probe
printf '\n[3/6] Generate synthetic cases and FFmpeg H.264 round trips\n'
python3 make_cases.py
printf '\n[4/6] Run baseline and threshold/known-region ablations\n'
build/core-probe generated/input.json ../results/swift-core-results.json | tee ../results/swift-core.log
printf '\n[5/6] Test candidate estimators; candidates are NOT accepted stitches\n'
python3 prototype_probe.py | tee ../results/prototype.log
build/core-probe generated/anchor-input.json ../results/anchor-ablation.json
printf '\n[6/6] Verify observed regressions and counterfactuals, not product acceptance\n'
python3 verify_results.py
