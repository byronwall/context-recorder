"""Prepare a Linux-only, source-verified probe. Does not change the upstream copies."""
from pathlib import Path
import hashlib
ROOT = Path(__file__).resolve().parent
EXPECTED = {'ShiftEstimator.swift':'b799fc666341d8522635fb5087a4188598f5a867',
            'Join.swift':'b229b5c6e2e2586e8e230be2f45ca72d25c00fea',
            'Segmenter.swift':'076137a8d25538a84f50521f696cfe1ec26a0fc1',
            'Storyboard.swift':'92148f80239793b898f1cde9621c38b816f6f24f'}
out = ROOT / 'build'
out.mkdir(exist_ok=True)
for name, expected in EXPECTED.items():
    data = (ROOT/'upstream'/name).read_bytes()
    actual = hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
    if actual != expected:
        raise RuntimeError(f'Source mismatch: {name}: {actual} != {expected}')
    text = data.decode()
    if name == 'ShiftEstimator.swift':
        text = text.split('/// Apple Vision\'s translational registration.')[0]
        text = text.replace('import CoreGraphics\n','').replace('import Vision\n','')
    if name == 'Segmenter.swift':
        text = text.replace('import CoreGraphics\n','')
    (out/name).write_text(text)
    print('[verified/prepared]', name)
