import Foundation

struct ImageSpec: Decodable { var path: String; var width: Int; var height: Int; var index: Int; var time: Double }
struct PairSpec: Decodable { var id: String; var a: ImageSpec; var b: ImageSpec; var knownCols: [Int]?; var expectedShift: Int?; var expected: String; var note: String? }
struct SequenceSpec: Decodable { var id: String; var frames: [ImageSpec] }
struct Input: Decodable { var pairs: [PairSpec]; var sequences: [SequenceSpec] }
func load(_ s: ImageSpec) throws -> DecodedFrame {
    let bytes = [UInt8](try Data(contentsOf: URL(fileURLWithPath: s.path)))
    guard bytes.count == s.width*s.height else { throw CanvasError("Raw byte count wrong: \(s.path)") }
    return DecodedFrame(ref: FrameRef(index: s.index, time: s.time), gray: GrayImage(width: s.width, height: s.height, pixels: bytes))
}
func describe(_ r: JoinResult) -> [String: Any] {
    switch r {
    case .same: return ["result":"same"]
    case .change: return ["result":"change"]
    case .noOverlap: return ["result":"no-overlap"]
    case .ambiguous: return ["result":"ambiguous"]
    case let .shift(s,t,b,c): return ["result":"shift", "shift":s,"fixedTop":t,"fixedBottom":b,"cols":[c.lowerBound,c.upperBound]]
    }
}
func summary(_ run: Run) -> [String: Any] {
    ["startFrame":run.start.ref.index,"lastFrame":run.last.ref.index,"reason":run.reason.rawValue,
     "isColumn":run.isColumn,"height":run.height,"y":run.y,"patchFrames":run.patches.map{ $0.frame.index },
     "patches":run.patches.map{["frame":$0.frame.index,"sourceY":$0.sourceY,"destY":$0.destY,"height":$0.height]}]
}
guard CommandLine.arguments.count == 3 else { fatalError("usage: core-probe inputs.json results.json") }
do {
    let input = try JSONDecoder().decode(Input.self, from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))
    let baseline = Joiner(settings: JoinSettings(), estimator: RowProfileEstimator())
    var pairResults: [[String:Any]] = []
    for pair in input.pairs {
        let a = try load(pair.a), b = try load(pair.b)
        let t = Date()
        var out = describe(baseline.join(a,b))
        out["id"] = pair.id; out["expected"] = pair.expected
        out["expectedShift"] = pair.expectedShift ?? NSNull()
        let (top,bottom) = baseline.fixedBands(a.gray,b.gray)
        let rows = (top > 0 ? top+4 : 0)..<(a.gray.height-(bottom > 0 ? bottom+4 : 0))
        if rows.count > 32, let est = RowProfileEstimator().estimate(a,b,rows:rows) {
            out["estimate"] = est.shift; out["cost"] = est.cost
            out["runnerUp"] = est.runnerUp ?? NSNull()
            out["residual"] = baseline.residualShare(a.gray,b.gray,shift:est.shift,rows:rows)
            out["fixedBands"] = [top,bottom]
        }
        out["halfChanged"] = Diff.changedCount(a.small,b.small,delta:24)
        if let cols = pair.knownCols, cols.count == 2 {
            out["knownRegionAblation"] = describe(baseline.join(a,b,cols:cols[0]..<cols[1]))
        }
        var sensitive = JoinSettings(); sensitive.ignorePixels = 80
        out["ignore80Ablation"] = describe(Joiner(settings:sensitive,estimator:RowProfileEstimator()).join(a,b))
        var permissive = JoinSettings(); permissive.maxResidual = 0.04
        out["residual4PercentAblation"] = describe(Joiner(settings:permissive,estimator:RowProfileEstimator()).join(a,b))
        out["probeSeconds"] = Date().timeIntervalSince(t)
        pairResults.append(out)
        print("pair",pair.id,out["result"]!,out["shift"] ?? "-", "estimate",out["estimate"] ?? "-")
    }
    var sequences: [[String:Any]] = []
    for seq in input.sequences {
        guard let first = seq.frames.first else { continue }
        var seg = Segmenter(settings:StoryboardSettings(),joiner:baseline,pixelCount:(first.width/2)*(first.height/2))
        var runs: [Run] = []
        for spec in seq.frames { runs += try seg.feed(load(spec)) }
        if let run = seg.finish() { runs.append(run) }
        let out: [String:Any] = ["id":seq.id,"frames":seq.frames.count,"runs":runs.map(summary),
                               "columns":runs.filter{ $0.isColumn }.count,"cards":runs.filter{ !$0.isColumn }.count]
        sequences.append(out); print("sequence",seq.id,"columns",out["columns"]!,"cards",out["cards"]!)
    }
    let out: [String:Any] = ["kind":"actual Swift algorithm with Linux metadata stubs","pairs":pairResults,"sequences":sequences]
    try JSONSerialization.data(withJSONObject:out,options:[.prettyPrinted,.sortedKeys]).write(to:URL(fileURLWithPath:CommandLine.arguments[2]))
} catch { fputs("core-probe error: \(error)\n",stderr); exit(1) }
