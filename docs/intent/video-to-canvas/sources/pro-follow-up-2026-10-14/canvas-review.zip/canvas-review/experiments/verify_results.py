"""Reproduction assertions: PASS means a documented behavior was reproduced, not that the product is correct."""
from pathlib import Path
import json,platform,subprocess
import numpy as np,cv2,PIL
ROOT=Path(__file__).resolve().parent.parent
r=json.loads((ROOT/'results/swift-core-results.json').read_text())
p={x['id']:x for x in r['pairs']};s={x['id']:x for x in r['sequences']}
proto=json.loads((ROOT/'results/prototype-results.json').read_text()); q={x['id']:x for x in proto['pairs']}
a=json.loads((ROOT/'results/anchor-ablation.json').read_text())['sequences'][0]
checks=[]
def test(name,condition):
    checks.append({'name':name,'passed':bool(condition)})
    print('[reproduced]' if condition else '[unexpected]',name)

test('clean integer scroll joins at correct 8 px',all(p[f'clean-{i}']['result']=='shift' and p[f'clean-{i}']['shift']==8 for i in range(3)))
test('fixed sidebar wins global zero-shift hypothesis',all(p[f'sidebar-{i}']['estimate']==0 and p[f'sidebar-{i}']['result']=='change' for i in range(3)))
test('oracle sidebar region restores original native joiner',all(p[f'sidebar-{i}']['knownRegionAblation'].get('shift')==8 for i in range(3)))
test('changing header badge prevents pure scroll join',all(p[f'header-badge-{i}']['result']!='shift' for i in range(3)))
test('oracle header exclusion restores joins',all(p[f'header-cropped-{i}'].get('shift')==8 for i in range(3)))
test('central pane is not discovered by full-width matcher',all(p[f'nested-{i}']['estimate']==0 for i in range(3)))
test('oracle central pane restores joins',all(p[f'nested-{i}']['knownRegionAblation'].get('shift')==8 for i in range(3)))
test('2px horizontal drift fails vertical-only verifier',all(p[f'dx2-{i}']['result']!='shift' for i in range(3)))
test('20x20 persistent edit ignored',p['small-persistent-edit']['result']=='same' and s['small-edit-held']['cards']==1)
test('lower pointer allowance detects edit pair only',p['small-persistent-edit']['ignore80Ablation']['result']=='change')
test('scroll with small edit classified as pure shift',p['small-edit-while-scroll'].get('shift')==8)
test('one-frame overlay splits a clean run',s['clean-scroll']['columns']==1 and s['one-frame-overlay']['columns']==2)
test('known bad frame skip plus valid bridge restores one run',s['overlay-skip-oracle']['columns']==1 and p['overlay-reacquire'].get('shift')==16)
test('half-pixel sequence fragments',s['slow-half-pixel']['columns']==12 and s['slow-half-pixel']['cards']==1)
test('integer-spaced anchor ablation forms one run',a['columns']==1 and a['cards']==0)
test('return visit is not represented by new provenance patches',s['return-inside-surface']['runs'][0]['lastFrame']==4 and s['return-inside-surface']['runs'][0]['patchFrames']==[0,1,2])
test('H264 round trip retains clean/overlay contrast',s['clean-h264']['columns']==1 and s['overlay-h264']['columns']==2)
test('native ambiguity guard rejects exactly periodic rows',p['periodic-rows']['result']=='ambiguous')
test('tile candidates recover moving minority pane alongside static background',all(any(abs(c['scrollY']-8)<.15 for c in q[f'nested-{i}']['tilePhaseCandidates']) for i in range(3)))
test('tile candidates recover 2-D displacement',all(any(abs(c['dx']-2)<.15 and abs(c['scrollY']-8)<.15 for c in q[f'dx2-{i}']['tilePhaseCandidates']) for i in range(3)))
test('sparse flow estimates half-pixel displacement on clean pairs',all(any(abs(c['scrollY']-.5)<.03 for c in q[f'fractional-half-{i}']['sparseFlowCandidates']) for i in range(3)))
test('tile estimator still proposes a shift on fundamentally periodic data',len(q['periodic-rows']['tilePhaseCandidates'])>0)
test('sparse flow still proposes spurious matches across scene jumps',all(len(q[f'jump-{i}']['sparseFlowCandidates'])>0 for i in range(3)))
summary={'kind':'reproduction assertions; not product acceptance','checks':checks,'passed':sum(x['passed'] for x in checks),'total':len(checks),
         'environment':{'os':platform.platform(),'python':platform.python_version(),'numpy':np.__version__,'opencv':cv2.__version__,'pillow':PIL.__version__,
         'swift':subprocess.check_output(['swift','--version'],text=True).strip(),'ffmpeg':subprocess.check_output(['ffmpeg','-version'],text=True).splitlines()[0]},
         'scope':'34 synthetic pairs, 10 baseline sequences/380 frames, one 20-frame anchor ablation. Metadata stubs replace macOS image/decoder types.',
         'unrun':['macOS package build','AVFoundation FrameSource execution','Vision estimator','CoreGraphics composition and PNG pixel validation','SwiftUI interaction/rendering','user recordings','production end-to-end performance','complete integrated replacement pipeline']}
(ROOT/'results/reproduction-checks.json').write_text(json.dumps(summary,indent=2)+'\n')
assert all(x['passed'] for x in checks),'A recorded reproduction changed; inspect raw results.'
