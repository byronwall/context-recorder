"""Synthetic diagnostic corpus. Not user recordings or a product accuracy benchmark.
Creates grayscale source arrays, inspectable PNGs, and optional H.264 round trips.
Requires already installed NumPy, Pillow, OpenCV, and ffmpeg; never installs packages.
"""
from pathlib import Path
import json, subprocess, shutil
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
ROOT = Path(__file__).resolve().parent
DATA = ROOT/'generated'
DATA.mkdir(exist_ok=True)
W,H = 640,360
FONT_PATH = '/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
FONT = ImageFont.truetype(FONT_PATH,13) if Path(FONT_PATH).exists() else ImageFont.load_default()

def page(seed: int, width: int = W, height: int = 2400) -> np.ndarray:
    rng = np.random.default_rng(seed)
    img = Image.new('L',(width,height),250); d=ImageDraw.Draw(img)
    words=['records','settings','navigation','projects','account','review','billing','content','export','activity']
    for i,y in enumerate(range(8,height-20,27)):
        x=12+int(rng.integers(0,9))
        text=f'{i:03d}  '+ ' '.join(rng.choice(words,int(rng.integers(2,6))))
        d.text((x,y),text,font=FONT,fill=int(rng.integers(20,90)))
        if i%4==0:
            d.rectangle((width-100,y+2,width-12,y+13),fill=int(rng.integers(90,210)))
        if i%9==0:
            d.line((8,y+21,width-8,y+21),fill=150,width=1)
    return np.asarray(img).copy()

def frame(p: np.ndarray, y: float, height: int=H) -> np.ndarray:
    yy,xx=np.mgrid[:height,:p.shape[1]].astype(np.float32)
    return cv2.remap(p,xx,yy+float(y),cv2.INTER_LINEAR,borderMode=cv2.BORDER_CONSTANT,borderValue=250)

def save(name: str, arr: np.ndarray, index: int=0, time: float|None=None, preview: bool=False) -> dict:
    arr=np.ascontiguousarray(arr,dtype=np.uint8)
    path=DATA/f'{name}.gray';path.write_bytes(arr.tobytes())
    if preview: Image.fromarray(arr).save(DATA/f'{name}.png')
    return {'path':str(path.relative_to(ROOT)),'width':arr.shape[1],'height':arr.shape[0],'index':index,'time':index/15 if time is None else time}

pairs=[]; seqs=[]
def pair(name,a,b,expected='shift',shift=8,cols=None,note=None):
    spec={'id':name,'a':save(name+'-a',a,preview=True),'b':save(name+'-b',b,1,preview=True),
          'expected':expected,'expectedShift':shift,'note':note}
    if cols is not None:spec['knownCols']=cols
    pairs.append(spec)

def sequence(name, arrays):
    spec={'id':name,'frames':[save(name+f'-{i:03}',a,i) for i,a in enumerate(arrays)]}
    seqs.append(spec)

for seed in range(3):
    p=page(seed)
    a,b=frame(p,120),frame(p,128)
    pair(f'clean-{seed}',a,b)
    # Stress test: a fixed high-detail sidebar beside a sparse moving document.
    rng=np.random.default_rng(seed+200)
    sidebar=np.repeat(rng.integers(35,205,(H,1),dtype=np.uint8),224,axis=1)
    aa=a.copy();bb=b.copy();aa[:,:224]=sidebar;bb[:,:224]=sidebar
    pair(f'sidebar-{seed}',aa,bb,cols=[224,W],note='Known-region ablation uses oracle x=224; not automatic region discovery.')
    # Header has a tiny changing badge touching the top edge.
    header=np.repeat(rng.integers(25,160,(56,1),dtype=np.uint8),W,axis=1)
    aa=a.copy();bb=b.copy();aa[:56]=header;bb[:56]=header
    bb[:12,320:344]=240
    pair(f'header-badge-{seed}',aa,bb)
    pair(f'header-cropped-{seed}',aa[56:],bb[56:],note='Known-region ablation: manually exclude the 56 px header.')
    # A narrow central scrolling pane inside a fixed, detailed application.
    fixed=frame(page(seed+10),300)
    aa=fixed.copy();bb=fixed.copy();aa[:,224:416]=a[:,224:416];bb[:,224:416]=b[:,224:416]
    pair(f'nested-{seed}',aa,bb,cols=[224,416],note='30%-width pane; known-region ablation is an oracle.')
    pair(f'nested-cropped-{seed}',aa[:,224:416],bb[:,224:416])
    # Two-dimensional displacement, while production only verifies y translation.
    shifted=cv2.warpAffine(b,np.float32([[1,0,2],[0,1,0]]),(W,H),borderValue=250)
    pair(f'dx2-{seed}',a,shifted,note='Content moved +2 px in x and -8 px in y.')
    pair(f'fractional-half-{seed}',frame(p,120),frame(p,120.5),shift=None,note='True down-scroll is 0.5 px; desired: track subpixel geometry, not a new state.')
    # Safe controls.
    pair(f'jump-{seed}',frame(p,0),frame(page(seed+500),800),expected='refuse',shift=None)

p=page(37)
a,b=frame(p,100),frame(p,108)
aa=a.copy();bb=a.copy();aa[150:170,300:320]=250;bb[150:170,300:320]=0
pair('small-persistent-edit',aa,bb,expected='change',shift=0,note='A persistent 20x20 edit, not a pointer.')
sequence('small-edit-held',[aa]*6+[bb]*15)
aa=a.copy();bb=b.copy();bb[150:170,300:320]=0
pair('small-edit-while-scroll',aa,bb,expected='scroll-plus-change',shift=8,note='The transform is valid, but changed overlap must be retained as a separate state/patch.')
aa=a.copy();bb=b.copy();bb[120:200,280:360]=30
pair('overlay-while-scroll',aa,bb,expected='scroll-plus-overlay',shift=8,note='Do not raise global residual and silently discard overlay pixels.')
# 40-row periodic content, inherently ambiguous without an anchor.
tile=page(71,height=40); rep=np.tile(tile,(70,1))
pair('periodic-rows',frame(rep,0),frame(rep,8),expected='refuse',shift=None)
pair('blank',np.full((H,W),250,np.uint8),np.full((H,W),250,np.uint8),expected='same',shift=0)
# Diagnostic collision: each row/bin has the same average but unique 2-D pixels.
rng=np.random.default_rng(731)
collision=np.empty((1000,W),np.uint8)
for y in range(1000):
    for x in range(0,W,40): collision[y,x:x+40]=rng.permutation(np.array([30]*20+[230]*20,np.uint8))
pair('profile-collision',frame(collision,0),frame(collision,8),note='Deliberately adversarial proof of information loss in 16-bin row means; not a natural UI benchmark.')
clean=[frame(p,100+8*i) for i in range(45)]
sequence('clean-scroll',clean)
overlay=[x.copy() for x in clean]
overlay[15][120:200,280:360]=30
sequence('one-frame-overlay',overlay)
# Counterfactual: known transient removed from geometric input, not a complete event-preserving implementation.
sequence('overlay-skip-oracle',[a for i,a in enumerate(overlay) if i!=15])
seqs[-1]['frames']=[s for s in next(q for q in seqs if q['id']=='one-frame-overlay')['frames'] if s['index']!=15]
pair('overlay-reacquire',overlay[14],overlay[16],shift=16,note='Can the unchanged native joiner recover across the known bad frame?')
sequence('slow-half-pixel',[frame(p,100+i/2) for i in range(40)])
sequence('return-inside-surface',[frame(p,100+i) for i in [0,40,80,40,0]])
# Test that image crop alone turns the sidebar sequence into a geometric run.
rng=np.random.default_rng(801)
sidebar=np.repeat(rng.integers(35,205,(H,1),dtype=np.uint8),224,axis=1)
side=[x.copy() for x in clean]
for x in side:x[:,:224]=sidebar
sequence('sidebar-scroll',side)
sequence('sidebar-cropped-scroll',[x[:,224:] for x in side])
# H.264 stress round trip of two synthetic 15 fps sequences; FFmpeg, not AVFoundation.
for name, arrays in [('clean-h264',clean),('overlay-h264',overlay)]:
    if not shutil.which('ffmpeg'):break
    video=DATA/f'{name}.mp4'
    cmd=['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','gray','-s',f'{W}x{H}',
         '-r','15','-i','pipe:0','-an','-c:v','libx264','-b:v','4M','-pix_fmt','yuv420p',str(video)]
    subprocess.run(cmd,input=b''.join(x.tobytes() for x in arrays),check=True)
    raw=subprocess.run(['ffmpeg','-v','error','-i',str(video),'-f','rawvideo','-pix_fmt','gray','pipe:1'],capture_output=True,check=True).stdout
    out=np.frombuffer(raw,np.uint8).reshape((-1,H,W))
    assert len(out)==len(arrays)
    sequence(name,list(out))
input={'pairs':pairs,'sequences':seqs}
(DATA/'input.json').write_text(json.dumps(input,indent=2)+'\n')
print('[corpus]',len(pairs),'pairs;',len(seqs),'sequences;',sum(len(s['frames']) for s in seqs),'sequence frames')
print('[corpus] All synthetic. Three seeds are diagnostic repetitions, not independent product evaluations.')
