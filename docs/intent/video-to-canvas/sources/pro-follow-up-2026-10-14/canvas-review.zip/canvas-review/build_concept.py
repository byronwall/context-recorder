"""Render a synthetic interaction concept, never a claimed native-app screenshot.
Images come from the exact raw inputs and Swift patch plans in this package.
"""
from pathlib import Path
import base64, io, json
from PIL import Image
import numpy as np
ROOT=Path(__file__).resolve().parent
EXP=ROOT/'experiments'
inputs=json.loads((EXP/'generated/input.json').read_text())
results=json.loads((ROOT/'results/swift-core-results.json').read_text())

def uri(a):
    f=io.BytesIO();Image.fromarray(a).save(f,format='PNG',optimize=True)
    return 'data:image/png;base64,'+base64.b64encode(f.getvalue()).decode()
def read(f):
    return np.frombuffer((EXP/f['path']).read_bytes(),np.uint8).reshape(f['height'],f['width'])
def scenario(name, offsets):
    spec=next(s for s in inputs['sequences'] if s['id']==name)
    res=next(s for s in results['sequences'] if s['id']==name)
    run=res['runs'][0]; assert len(res['runs'])==1
    frames={f['index']:f for f in spec['frames']}
    top=min(p['destY'] for p in run['patches']);bottom=max(p['destY']+p['height'] for p in run['patches'])
    w=spec['frames'][0]['width']; h=bottom-top
    atlas=np.zeros((h,w),np.uint8);owned=np.zeros(h,dtype=bool)
    owners=np.full(h,-1,dtype=np.int32)
    for p in run['patches']:
        arr=read(frames[p['frame']]);y=p['destY']-top
        atlas[y:y+p['height']]=arr[p['sourceY']:p['sourceY']+p['height']]
        owners[y:y+p['height']]=p['frame'];owned[y:y+p['height']]=True
    assert owned.all(), 'Unknown rows must not be filled in a demo'
    # Validate only this Python rendering against the synthetic ground-truth views.
    # This is not the macOS compositor under test.
    for f,dy in zip(spec['frames'],offsets):
        view=read(f)
        assert np.array_equal(atlas[dy-top:dy-top+view.shape[0]],view),f'Preview mismatch {name} {f["index"]}'
    return {'name':name,'width':w,'height':h,'viewportHeight':spec['frames'][0]['height'],
      'atlas':uri(atlas),'owners':owners.tolist(),
      'frames':[{'index':f['index'],'time':f['time'],'y':dy-top,'src':uri(read(f))} for f,dy in zip(spec['frames'],offsets)]}
# Inspect actual input IDs instead of inventing the return name.
return_name=next(s['id'] for s in inputs['sequences'] if 'return' in s['id'])
scenes=[scenario('clean-scroll',[8*i for i in range(45)]),scenario(return_name,[0,40,80,40,0])]
pairs={p['id']:p for p in inputs['pairs']}
edit=pairs['small-persistent-edit']
a,b=read(edit['a']),read(edit['b']); yy,xx=np.nonzero(a!=b)
edit_data={'before':uri(a),'after':uri(b),'x':int(xx.min()),'y':int(yy.min()),'width':int(xx.max()-xx.min()+1),'height':int(yy.max()-yy.min()+1),'pixels':int(len(xx))}
diag=[]
for name,desc in [('sidebar-0','The global winner is zero, so moving-column discovery never starts. A known moving-region crop restores the 8 px join.'),('header-badge-0','A changing badge at the top defeats the fixed-band edge scan. Excluding the known header restores the 8 px join.'),('nested-0','A narrow central pane moves while the majority is stationary. Local proposals recover both zero and moving hypotheses.'),('dx2-0','Two pixels of x displacement are enough to defeat the y-only verifier in this synthetic case.')]:
    p=pairs[name]; r=next(r for r in results['pairs'] if r['id']==name)
    diag.append({'id':name,'before':uri(read(p['a'])),'after':uri(read(p['b'])),'description':desc,'native':r})
data={'scenes':scenes,'edit':edit_data,'diagnostics':diag}
html='''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Canvas atlas — interaction concept</title><style>
:root{color-scheme:light;--ink:#17212e;--muted:#596979;--line:#dce3ea;--paper:#fff;--accent:#176651;--tint:#e9f5ef}*{box-sizing:border-box}body{margin:0;background:#f3f6f8;color:var(--ink);font:15px/1.55 system-ui,-apple-system,sans-serif}header{padding:28px max(24px,calc((100vw - 1320px)/2));background:var(--paper);border-bottom:1px solid var(--line)}.eyebrow{text-transform:uppercase;letter-spacing:.13em;font-size:11px;font-weight:750;color:var(--accent)}h1{font-size:30px;line-height:1.2;margin:6px 0 10px}p{margin:8px 0}header p{max-width:1000px;color:var(--muted)}main{max-width:1368px;margin:auto;padding:24px}.tabs{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px}button,select{font:inherit;border:1px solid var(--line);border-radius:8px;background:white;color:var(--ink);padding:8px 12px;cursor:pointer}button[aria-selected=true],button.active{background:var(--accent);border-color:var(--accent);color:white}button:hover{filter:brightness(.96)}:focus-visible{outline:3px solid #2c79ca;outline-offset:3px}button:disabled{opacity:.4;cursor:default}[hidden]{display:none!important}.panel{background:white;border:1px solid var(--line);border-radius:12px;padding:20px}.grid{display:grid;grid-template-columns:minmax(0,1.15fr) minmax(300px,.85fr);gap:20px;align-items:start}h2{margin:0 0 8px;font-size:20px}h3{font-size:15px;margin:0 0 10px}.sub{font-size:13px;color:var(--muted)}.tag{display:inline-flex;padding:3px 8px;border:1px solid var(--line);border-radius:6px;background:#f7fafb;font-size:12px}.controls{display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin:12px 0}input[type=range]{width:100%;accent-color:var(--accent)}.atlas-wrap{position:relative;width:100%;max-width:640px;margin:18px auto 0;cursor:crosshair;line-height:0;border:1px solid var(--line)}.atlas-wrap img{width:100%;display:block}.viewport{position:absolute;left:0;right:0;border:3px solid var(--accent);pointer-events:none;background:rgba(23,102,81,.045)}.viewport span{position:absolute;right:0;top:0;line-height:1.5;background:var(--accent);padding:3px 7px;color:white;font:12px/1.5 system-ui}.preview{display:block;width:100%;height:auto;border:1px solid var(--line);border-radius:6px;margin:12px 0}.rail{display:flex;gap:7px;overflow:auto;padding:4px 0 12px}.rail button{flex:none;min-width:65px;font-size:12px}.callout{padding:12px 14px;border-left:3px solid var(--accent);background:var(--tint);margin:16px 0;color:#28483f}.reading{margin-top:20px;padding:16px;border-top:1px solid var(--line)}.reading p{max-width:980px;color:var(--muted)}.sticky{position:sticky;top:16px}.stat{font-variant-numeric:tabular-nums;font-weight:700}.change-wrap{position:relative;line-height:0}.change-wrap img{display:block;width:100%}.change-box{position:absolute;border:2px solid #aa4a00;pointer-events:none}.change-box:after{content:'Persistent change';position:absolute;bottom:100%;left:0;white-space:nowrap;background:#aa4a00;color:white;font:11px/1.5 system-ui;padding:2px 5px}.raw{font:12px/1.6 ui-monospace,monospace;white-space:pre-wrap;overflow-wrap:anywhere;max-height:300px;overflow:auto;background:#f4f6f8;padding:12px;border-radius:8px}footer{font-size:12px;color:var(--muted);max-width:1320px;margin:0 auto;padding:0 24px 32px}@media(max-width:850px){.grid{grid-template-columns:1fr}.sticky{position:static}h1{font-size:25px}main{padding:16px}.panel{padding:16px}}
</style></head><body>
<header><div class="eyebrow">Context Recorder · design exploration</div><h1>One document. Every moment still available.</h1><p>A stable atlas, a recorded-viewport lens, and source evidence without leaving the canvas. The content below is synthetic diagnostic data, not a user recording or a screenshot of a shipped feature.</p></header>
<main><nav class="tabs" role="tablist" aria-label="Concept views"><button role="tab" id="tab-atlas" aria-controls="atlas" aria-selected="true" data-tab="atlas">Atlas & time</button><button role="tab" id="tab-changes" aria-controls="changes" aria-selected="false" data-tab="changes">Local changes</button><button role="tab" id="tab-diagnostics" aria-controls="diagnostics" aria-selected="false" data-tab="diagnostics">Why not joined?</button></nav>
<section id="atlas" role="tabpanel" aria-labelledby="tab-atlas"><div class="grid"><article class="panel"><div class="eyebrow">Stable document coordinates</div><h2>Scrub time; keep the page in place</h2><p class="sub">Click any image row to inspect its contributing source frame. The outline shows the active observation, which is a different concept from pixel ownership.</p><div class="controls"><label for="scenario">Scenario</label><select id="scenario"><option value="0">Clean vertical scroll · 45 frames</option><option value="1">Down, then back · 5 observations</option></select><span class="tag" id="atlas-size"></span></div><div class="atlas-wrap" id="atlas-hit" tabindex="0" role="button" aria-label="Document atlas. Click a row for its contributing frame. Use left and right arrows to step observations."><img id="atlas-img" alt="Synthetic document reconstructed from the Swift run patch plan"><div class="viewport" id="viewport"><span id="viewport-label"></span></div></div></article>
<aside class="panel sticky"><div class="eyebrow">Source preview stays here</div><h2 id="frame-title">Observation</h2><p class="sub" id="pose"></p><img id="source-img" class="preview" alt="Exact synthetic input frame at the selected observation"><div class="controls"><button id="previous" aria-label="Previous observation">Previous</button><button id="next" aria-label="Next observation">Next</button><output id="time" class="stat" aria-live="polite"></output></div><label for="scrubber" class="sub">Recorded observations</label><input id="scrubber" type="range" min="0" max="44" value="0" step="1"><p id="ownership" class="callout" aria-live="polite"></p><h3>Journey ribbon</h3><div class="rail" id="rail"></div><p class="sub" id="visit-note"></p><div class="reading"><h3>Proposed interaction</h3><p>Keep narration and playback attached to the active visit. Preserve contributor time separately. Repeated visits should not require duplicate page images.</p><p>No transcript is invented for this demonstration. A full source-video command can coexist with this inline preview.</p></div></aside></div></section>
<section id="changes" role="tabpanel" aria-labelledby="tab-changes" hidden><div class="grid"><article class="panel"><div class="eyebrow">Version only what changed</div><h2>A small edit should not disappear</h2><p class="sub">This 400-pixel persistent edit was classified as “same” by the current joiner. The proposed view attaches a local state change to the document rather than requiring another full-width card.</p><div class="controls"><button id="before">Before</button><button id="after" class="active">After</button><span class="tag">Proposed state display · known test change</span></div><div class="change-wrap"><img id="edit-img" alt="Synthetic persistent edit test"><div class="change-box" id="edit-box"></div></div></article><aside class="panel"><h2>Keep geometry and versions separate</h2><p>Successful alignment answers where content belongs. It does not answer whether the content is unchanged.</p><div class="callout">Preserve both source observations. A compact change marker can open a before/after view; a major page redesign can branch into a full successor state.</div><p class="sub">The displayed change rectangle comes from known synthetic pixels. Automatic change classification, state grouping, and native editing are not implemented by this concept.</p></aside></div></section>
<section id="diagnostics" role="tabpanel" aria-labelledby="tab-diagnostics" hidden><article class="panel"><div class="eyebrow">Explain uncertainty, do not hide it</div><h2>Inspect the actual failed pair</h2><div class="controls"><label for="failure">Case</label><select id="failure"></select></div><p id="failure-desc"></p><div class="grid"><div><h3>Previous source frame</h3><img id="failure-a" class="preview" alt="Previous frame in selected diagnostic case"></div><div><h3>Current source frame</h3><img id="failure-b" class="preview" alt="Current frame in selected diagnostic case"></div></div><details><summary>Raw native-probe result and ablations</summary><pre class="raw" id="failure-raw"></pre></details><div class="callout">A future correction should change the tracked region or group a related unaligned continuation. It must not silently turn “related” into “geometrically verified.”</div></article></section>
</main><footer>Evidence: pinned main 76afc4faa24887408c275360132f0dd03384c94b. Atlas raster: Python rendering of the actual Swift patch plan. Viewport poses: synthetic fixture ground truth. This is an interaction proposal, not a native-app test. All assets are embedded; no external requests are needed.</footer>
<script id="concept-data" type="application/json">__DATA__</script><script>
'use strict';
const data=JSON.parse(document.getElementById('concept-data').textContent);
const $=id=>document.getElementById(id);
let sceneIndex=0,frameIndex=0,clickedRow=null;
function scene(){return data.scenes[sceneIndex];}
function selectFrame(index){
 const s=scene();frameIndex=Math.max(0,Math.min(s.frames.length-1,index));const f=s.frames[frameIndex];
 $('source-img').src=f.src;$('frame-title').textContent=`Observation ${frameIndex+1} of ${s.frames.length}`;
 $('time').textContent=`${f.time.toFixed(3)} s · frame ${f.index}`;$('pose').textContent=`Document y = ${f.y} px · viewport height ${s.viewportHeight} px`;
 $('scrubber').value=String(frameIndex);$('previous').disabled=frameIndex===0;$('next').disabled=frameIndex===s.frames.length-1;
 $('viewport').style.top=`${f.y/s.height*100}%`;$('viewport').style.height=`${s.viewportHeight/s.height*100}%`;
 $('viewport-label').textContent=`Active observation · ${f.time.toFixed(3)} s`;
 const y=clickedRow===null?Math.min(s.height-1,Math.floor(f.y+s.viewportHeight/2)):clickedRow;
 const owner=s.owners[y];
 $('ownership').textContent=`Atlas row ${y}: pixels contributed by frame ${owner}. Active observation: frame ${f.index}. ${owner===f.index?'These happen to match.':'They need not be the same moment.'}`;
 $('visit-note').textContent=sceneIndex===1?'The last two observations return over existing pixels. They create new moments to navigate, but do not need new page patches.':'This continuous scroll adds new rows. The page stays stable while time moves through it.';
 for(const b of $('rail').children)b.classList.toggle('active',Number(b.dataset.frame)===frameIndex);
}
function selectScene(index){
 sceneIndex=index;clickedRow=null;const s=scene();$('atlas-img').src=s.atlas;$('atlas-size').textContent=`${s.width} × ${s.height} observed px`;
 $('scrubber').max=String(s.frames.length-1);$('rail').replaceChildren();
 const indices=s.frames.length<=8?s.frames.map((_,i)=>i):[0,8,16,24,32,40,44];
 for(const i of indices){const b=document.createElement('button');b.textContent=`Frame ${s.frames[i].index}`;b.dataset.frame=String(i);b.addEventListener('click',()=>{clickedRow=null;selectFrame(i);});$('rail').append(b);}
 selectFrame(0);
}
function inspectRow(event){
 const bounds=$('atlas-img').getBoundingClientRect();const s=scene();
 clickedRow=Math.max(0,Math.min(s.height-1,Math.floor((event.clientY-bounds.top)/bounds.height*s.height)));
 const owner=s.owners[clickedRow],index=s.frames.findIndex(f=>f.index===owner);
 if(index<0)return;selectFrame(index);
}
function selectDiagnostic(index){const d=data.diagnostics[index];$('failure-a').src=d.before;$('failure-b').src=d.after;$('failure-desc').textContent=d.description;$('failure-raw').textContent=JSON.stringify(d.native,null,2);}
for(const b of document.querySelectorAll('[data-tab]'))b.addEventListener('click',()=>{
 const active=b.dataset.tab;
 for(const tab of document.querySelectorAll('[data-tab]')){const on=tab.dataset.tab===active;tab.setAttribute('aria-selected',String(on));$(tab.dataset.tab).hidden=!on;}
});
$('scenario').addEventListener('change',e=>selectScene(Number(e.target.value)));
$('scrubber').addEventListener('input',e=>{clickedRow=null;selectFrame(Number(e.target.value));});
$('previous').addEventListener('click',()=>{clickedRow=null;selectFrame(frameIndex-1);});
$('next').addEventListener('click',()=>{clickedRow=null;selectFrame(frameIndex+1);});
$('atlas-hit').addEventListener('click',inspectRow);
$('atlas-hit').addEventListener('keydown',e=>{if(e.key!=='ArrowLeft'&&e.key!=='ArrowRight')return;e.preventDefault();clickedRow=null;selectFrame(frameIndex+(e.key==='ArrowRight'?1:-1));});
$('before').addEventListener('click',()=>{$('edit-img').src=data.edit.before;$('before').classList.add('active');$('after').classList.remove('active');});
$('after').addEventListener('click',()=>{$('edit-img').src=data.edit.after;$('after').classList.add('active');$('before').classList.remove('active');});
$('edit-img').src=data.edit.after;Object.assign($('edit-box').style,{left:`${data.edit.x/640*100}%`,top:`${data.edit.y/360*100}%`,width:`${data.edit.width/640*100}%`,height:`${data.edit.height/360*100}%`});
data.diagnostics.forEach((d,i)=>{const o=document.createElement('option');o.value=String(i);o.textContent=d.id;$('failure').append(o);});
$('failure').addEventListener('change',e=>selectDiagnostic(Number(e.target.value)));
selectScene(0);selectDiagnostic(0);console.info('[canvas concept] synthetic sources loaded; this is not the native app');
</script></body></html>
'''
(ROOT/'canvas-concepts.html').write_text(html.replace('__DATA__',json.dumps(data,separators=(',',':')).replace('</','<\\/')))
(ROOT/'results/concept-data-checks.json').write_text(json.dumps({'kind':'Python-rendered concept data checks, not native compositor validation','scenarios':len(scenes),'sourceViewsChecked':sum(len(s['frames']) for s in scenes),'allViewsMatchSyntheticAtlasCrop':True,'unknownRowsFilled':False,'browserExecution':'unrun; browser executable unavailable','nativeInteraction':'unrun'},indent=2)+'\n')
print('[concept] 50 source views checked against Python-rendered patch plans; wrote self-contained HTML')
