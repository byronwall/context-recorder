"""Assemble review documents and a self-contained interaction concept from recorded probe outputs.
This does not access or edit a repository or a personal recording.
"""
from pathlib import Path
import base64, hashlib, io, json, re
from PIL import Image
import numpy as np

ROOT = Path(__file__).resolve().parent
COMMIT = '76afc4faa24887408c275360132f0dd03384c94b'
BASE = f'https://github.com/byronwall/context-recorder/blob/{COMMIT}/'
DATE = 'October 14, 2026, America/Indiana/Indianapolis'
repo_sources = [
 ('R1','Sources/CanvasKit/CanvasAnalyzer.swift','full','CanvasAnalyzer.Options/build/compose; every decoded frame; default estimator; item emission and images.'),
 ('R2','Sources/CanvasKit/ShiftEstimator.swift','full','RowProfileEstimator.estimate/profiles/cost; integer shift, 16 bins, shortlist; VisionEstimator ignores cols and discards x.'),
 ('R3','Sources/CanvasKit/Join.swift','full','JoinSettings; Joiner.join, inPlace, fixedBands, residualShare, scrollingColumns, detailRows.'),
 ('R4','Sources/CanvasKit/Segmenter.swift','full','Segmenter.feed/finish; Run.append; immediate run termination, settling, novel-row ownership, return history.'),
 ('R5','Sources/CanvasKit/Storyboard.swift','full','StoryboardSettings and Diff.changedCount; half-resolution gate and settling/motion thresholds.'),
 ('R6','Sources/CanvasKit/CanvasDocument.swift','full','CanvasDocument, CanvasItem, Patch, FrameRef; flat items, row-to-source ownership, sourceRegion selection clipping.'),
 ('R7','Sources/ContextRecorder/Library/CanvasStage.swift','full','CanvasStage, CanvasStrip, CanvasImages; horizontal layout, hover, click, image cache, export, selection.'),
 ('R8','Sources/ContextRecorder/Library/CanvasModel.swift','full','SessionModel canvas extension; crop/rebuild, showSource changes stage, source-frame-only region marks.'),
 ('R9','Sources/CanvasKit/FrameSource.swift','full','FrameSource.next; all decoded presentation timestamps, raw image conversion, GrayImage.halved.'),
 ('R10','Sources/CanvasTool/Check.swift','full','Check.run/checkStoryboard/checkSeeks; existing native fixture and source-time checks.'),
 ('R11','Sources/CanvasTool/Geometry.swift','full','Geometry.check: no-column early return, accepted-patch error, mapping checks, maxColumns upper bound.'),
 ('R12','Sources/CanvasTool/Fixtures.swift','lines 1–250','Fixture cases, truth model, integer scroll positions, fixed selected region, synthetic encoding; rest of renderer not read.'),
 ('R13','extension/page.js','lines 1–40','STREAM includes click/nav/console/error/request, not scroll. Blob matches the previous packet copy.'),
 ('R14','Sources/CanvasTool/main.swift','full','Existing CLI commands and argument names for disposable native checks.'),
 ('R15','Package.swift','full','macOS 26, native CanvasKit/CanvasTool, optimization flags; test target is AnnotationTests.'),
 ('R16','README.md','partial response; Canvas section read','Documented current canvas actions and behavior; not an independent performance measurement.'),
]
external = [
 ('E1','Apple — VNTranslationalImageRegistrationRequest','https://developer.apple.com/documentation/vision/vntranslationalimageregistrationrequest','Translation-registration API exists. No evidence here that it solves nested scrolling or UI state identity. The repository wrapper defect is established by R2, not Apple documentation.'),
 ('E2','OpenCV — motion analysis / phaseCorrelate','https://docs.opencv.org/4.13.0/d7/df3/group__imgproc__motion.html','phaseCorrelate accepts optional windowing and returns a subpixel translation and response. The response is a correlation statistic, not a product-level probability of a truthful stitch.'),
 ('E3','OpenCV — object tracking / calcOpticalFlowPyrLK','https://docs.opencv.org/4.13.0/dc/d6b/group__video__track.html','Sparse pyramidal Lucas–Kanade optical-flow API used in the diagnostic probe; ECC translation model is another API option, not a tested recommendation.'),
 ('E4','W3C — CSSOM View Module','https://www.w3.org/TR/cssom-view/','Document/element/visual viewport coordinates and scrolling are distinct. Used to frame optional future browser geometry telemetry, not to claim current extension support.'),
]
lines = ['# Source ledger and evidence boundaries', '', f'Access/review date: **{DATE}**.', '',
 f'Connected GitHub resolved main to **`{COMMIT}`**. All implementation reads were pinned to that commit. The older source packet at `016684895df51872aeea1be5e93e28419fd63a7f` was used only as historical context, not as evidence of the shipped canvas.', '',
 '## Repository reading inventory', '',
 'Thirteen complete source files and three targeted/partial reads are listed below. Branch, tree, Library, and Tests listings were also read. This is a focused canvas review, not a claim to have read every file in the repository. No unpushed working tree was available.', '']
for sid,path,coverage,claims in repo_sources:
    lines += [f'### {sid} — `{path}`',f'- Source: [{path}]({BASE+path})',f'- Coverage: {coverage}.',f'- Supports: {claims}', '']
lines += ['## Primary external sources', '', 'The OpenCV 4.x documentation routes resolved to 4.13.0 in this run. Installed diagnostic APIs were also 4.13.0. This is not a claim that 4.13.0 is the newest release on every channel.', '']
for sid,title,url,claims in external:
    lines += [f'### {sid} — {title}',f'- Source: [{title}]({url})',f'- Accessed: {DATE}.',f'- Supports: {claims}', '']
lines += ['## Local experimental evidence', '',
 '`results/source-verification.json` records Git blob hashes and SHA-256 values for the four verbatim upstream files used in the probe. `experiments/prepare_swift.py` rechecks the blob hashes before execution.', '',
 '`results/swift-core-results.json` records actual executions of the row-profile estimator, join checks, half-size gate, Segmenter, and Run patch planning under Linux metadata stubs. It is not a reimplementation of those algorithms in Python. The unavailable Vision implementation is excluded, and decoding/image rendering are stubbed.', '',
 '`results/prototype-results.json` records diagnostic OpenCV motion proposals. These are not accepted stitches or an integrated alternative segmenter. `results/anchor-ablation.json` records the separate geometry-anchor ablation. `results/reproduction-checks.json` contains the 23 reproduced behavioral assertions and environment versions.', '',
 'Synthetic fixtures deliberately isolate failure mechanisms. Known crops and a skipped known transient are oracle interventions. They establish that recoverable geometry exists, not that automatic region discovery or transient classification is solved. All generated content is synthetic; no user recording or browsing history was fetched.', '',
 '## Material gaps', '',
 'The macOS app build, AVFoundation decoder, Apple Vision, Core Graphics compositor, AVPlayer seek behavior, SwiftUI interactions, real-recording coverage, and integrated replacement pipeline remain unrun. FFmpeg H.264 round trips are not an Apple end-to-end capture test. No claim is made about the frequency of these failures in real use, or about production speed/memory.', '',
 'The HTML concept uses synthetic probe images and the clean run’s patch plan, rendered by Python for demonstration. Its source-coordinate checks and JavaScript syntax are checked separately; browser interaction and native integration are not validated by those checks.', '',
 'Recommendations VCI-01 through VCI-10 and UI layouts are proposals unless an explicitly named experiment is reported. Numerical acceptance thresholds are provisional. No repository files were changed, committed, pushed, or published.', '']
(ROOT/'sources.md').write_text('\n'.join(lines))

report = (ROOT/'canvas-review.md').read_text()
sections = re.findall(r'### (VCI-\d+) — ([^\n]+)\n(.*?)(?=\n### VCI-|\n## A different canvas)', report, re.S)
extras = [
 ('Preserve ordinary scrolling beside static chrome.','Known user crop only; whole-frame matching.','small-to-medium','high for reproduced defect; medium for automatic region discovery','Region oracle plus local candidate probes executed; integrated automatic discovery unrun.', ['R3','R8'], []),
 ('Prevent one recoverable observation from fragmenting the page.','Immediate split; unconstrained joining across every gap.','medium','high for reproduced fragmentation; medium for proposed recovery policy','Known-transient skip and verified bridge executed; automatic recovery unrun.', ['R4'], []),
 ('Handle scaled screen motion without alternating false changes.','Integer anchors while retaining event inspection; unrestricted image warps rejected.','medium-to-large','high for reproduced issue; medium for full native transform/render fix','Half-pixel and x-drift probes executed; 20-frame anchor ablation executed; compositor unrun.', ['R2','R3','R4'], ['E2','E3']),
 ('Keep dynamic header islands from invalidating document alignment.','One-pair fixed edge scan; manually excluding header.','medium','high for reproduced failure; medium for automatic masks','Known-header crop executed; automatic temporal mask unrun.', ['R3'], []),
 ('Preserve changed overlap content without needlessly splitting geometry.','Single residual cutoff deciding both motion and state.','medium','high for content-loss mechanism; medium for change-layer design','Small scrolling edit accepted as shift reproduced; integrated state patches unrun.', ['R3','R4'], []),
 ('Keep small persistent edits while suppressing genuinely transient pointers.','Lower ignorePixels only; fixed fraction-of-frame thresholds.','small-to-medium','high for reproduced edit loss; medium for component/persistence model','20x20 edit and threshold ablation executed; cursor false-positive matrix unrun.', ['R3','R5'], []),
 ('Recover local motion without accepting periodic aliases or cross-cut matches.','Row profiles alone; single strongest phase/flow response.','medium','high for proposal/verification distinction; medium for combined verifier','2-D candidate probes and negative controls executed; Vision wrapper execution unrun.', ['R2','R3'], ['E1','E2','E3']),
 ('Constrain future browser recordings with actual geometry measurements.','Video-only inference; sparse mark snapshots; full DOM recording not needed initially.','medium','medium; entirely proposed instrumentation','Telemetry, clock calibration, nested-scroll capture, and latency tests unrun.', ['R1','R13'], ['E4']),
 ('Make return visits, narration, source preview, and changes navigable.','Flat run-to-item mapping; deduplicate away later visits.','medium','high for missing visit evidence; medium for next schema','Five-frame return patch-history test executed; observation/visit model unrun.', ['R4','R6','R7','R8'], []),
 ('Measure useful reconstruction, expose failure causes, and permit limited corrections.','All-card fallback treated as success; large benchmark/editor platform.','small-to-medium','high for source-level test gap; provisional numeric gates','Native Geometry guard inspected; 23 Linux reproduction assertions executed; native expanded gates unrun.', ['R10','R11','R12'], []),
]
def para(text, key):
    m = re.search(r'\*\*'+re.escape(key)+r'\.\*\* (.*?)(?=\n\n\*\*|\Z)',text,re.S)
    return m.group(1).strip() if m else ''
recs=[]
for rank,((rid,title,body),ex) in enumerate(zip(sections,extras),1):
    benefit,alternatives,cost,confidence,validation,refs,ext=ex
    proposal=para(body,'Change')
    if not proposal:
        raise ValueError(f'Missing change section {rid}')
    recs.append(dict(id=rid,rank=rank,title=title,problem=para(body,'Problem'),proposal=proposal,
        repositoryEvidence=[dict(id=sid,path=next(p for s,p,_,_ in repo_sources if s==sid),url=BASE+next(p for s,p,_,_ in repo_sources if s==sid)) for sid in refs],
        externalSources=[dict(id=sid,url=next(url for s,_,url,_ in external if s==sid)) for sid in ext],
        alternatives=alternatives,benefit=benefit,cost=cost,confidence=confidence,
        validation=validation,status='proposed; diagnostic evidence only, not integrated or shipped'))
assert len(recs)==10
(ROOT/'canvas-improvements.json').write_text(json.dumps(recs,indent=2,ensure_ascii=False)+'\n')

(ROOT/'codex-next-steps.md').write_text('''# Codex handoff: improve reconstruction before adding more cards

Baseline reviewed: `76afc4faa24887408c275360132f0dd03384c94b`. Reconcile later local changes before applying these recommendations. This package is analysis and diagnostics, not a patch to the repository.

## First scoped change: expose and repair continuity

Start with VCI-10 diagnostics and regression fixtures; implement VCI-01 region hypotheses and VCI-02 bounded recovery. Protect VCI-06 small persistent edits while tuning. Do not combine all ten recommendations into one large rewrite.

| File / symbol | Intended scope |
|---|---|
| `Sources/CanvasKit/Join.swift` / `Joiner.join` | Try independent region hypotheses even when the global winner is zero. Emit structured alignment/rejection diagnostics. Keep a verified moving-region result distinct from unaligned grouping. |
| `Sources/CanvasKit/ShiftEstimator.swift` | Preserve a candidate bank, including zero and alternative translations. Fix `VisionEstimator` column cropping before any renewed bakeoff. Do not interpret a single response as certainty. |
| `Sources/CanvasKit/Segmenter.swift` / `feed` | Add a bounded uncertain interval and reliable-anchor retry. Separate settling clock from geometry anchor. Keep transient observations even when geometry is recovered. |
| `Sources/CanvasKit/Join.swift` / `inPlace` and `Storyboard.swift` | Replace area-only ignore behavior with component persistence. Keep the existing pointer controls as explicit negative tests. |
| `Sources/CanvasTool/Fixtures.swift`, `Check.swift`, `Geometry.swift` | Add positive reconstruction coverage, fragmentation, and lost-edit checks; distinguish intentional `--storyboard` from unexpected all-card output. |

A minimal native result contract could contain `candidateTransform`, `verifiedRegion`, `residualComponents`, and `rejectionReason`. Keep dimensions and units explicit. This is a proposed contract, not source that compiles as supplied.

### Acceptance gates for the first change

These are proposed gates, not measured product results:

1. Clean continuous integer scrolling must reconstruct a column, not merely avoid a false stitch. Target at least 90% of ground-truth novel document area in correctly registered output on the directed corpus, with no more than one unexplained break per continuous short scroll. Exclude unobserved gaps from the denominator; count observed-but-lost content as failure.
2. On accepted geometry, target 95th-percentile displacement error at most 2 source pixels and no placement error over 4 pixels on these controlled fixtures. Preserve repeated-row/no-overlap refusals; fewer cards never compensates for a false join.
3. A visible persistent one-digit/checkbox/20×20 edit must remain discoverable. An overlay that is not stitched must remain available as an event or source observation. Cursor-only controls must not explode into cards.
4. Every owned patch and every visit must map to the correct source region/time. Native source seeks and selected composite export need their own checks; Linux metadata probes do not certify them.

Use the existing clean, reversal, header, jump, repeated, blank, cursor, and edit fixtures plus only a few new cases: detailed stationary sidebar, narrow nested pane, changed header badge, 0.5-pixel motion, 2-pixel x drift, and one transient overlay. Add three consented disposable real recordings before claiming everyday improvement: product page, nested application pane, and code/slide walkthrough. Those recordings are not part of this package.

## Second scoped change: improve geometry and preserve state

VCI-03/04/05/07: floating-point poses or stable geometry anchors, temporal fixed/dynamic masks, separate aligned content changes, and 2-D candidate verification. Keep source observations at every inspected frame even when geometry anchors are less frequent. Integer raster output must not be confused with integer accumulated motion. Preserve old pixels and state transitions; do not update an already-owned region silently.

Test both fractional raster phase and true content changes. Probe crop-size sensitivity and small x motion. Do not jump to arbitrary homographies, machine-learning scene segmentation, or OCR to compensate for the current region/continuity bugs.

## Third scoped change: make the canvas an atlas, not a run log

VCI-09: add a compact observation/pose log plus stable surface and state identities. `Run` can remain a temporary analysis object. `CanvasDocument` should retain source ownership separately from visits.

`CanvasStage` should default to a stable document view with a moving recorded-viewport rectangle, an inline source preview, and a chronological visit ribbon. `showSource` can keep its explicit full-video command, but ordinary exploration should not require leaving the canvas. Use state branches for meaningful changes, not every low-confidence frame. Show unaligned continuations with visible gaps.

Keep two selection actions: the existing single-source-frame mark and a new observed-canvas-composite export with source provenance. Do not silently change what a review mark means.

## Optional future capture aid

VCI-08 geometry telemetry should follow a demonstrated browser-only benefit. It needs nested-container identity, document epoch, fractional CSS offsets, viewport calibration, clock uncertainty, and resize/zoom handling. It must not make existing video-only recordings unusable.

## Reproduction run sheet

The first block runs this package's Linux diagnostics using already installed tools. It overwrites only generated experiment files/results inside this package. No dependency installation is performed. Fixture pixels depend on the recorded font/environment; the exact inputs used here are included for direct inspection.

```bash
# From the extracted canvas-review package. Requires Swift, Python, NumPy, Pillow,
# OpenCV, and FFmpeg already installed. The recorded environment is in results/.
cd /path/to/canvas-review/experiments
./run.sh
```

The following is a separate macOS run sheet using actual repository CLI options. These native commands were not executed in this review. The fixture command writes disposable files, and analyze replaces derived canvas output in the specified session copy. Do not point it at the only copy of a valuable session.

```bash
# Run from the repository on macOS 26 with the supported toolchain.
# Use a new disposable fixture directory; do not run build-app.sh for this review.
FIXTURES="$(mktemp -d "${TMPDIR:-/tmp}/canvas-review-fixtures.XXXXXX")"
swift run canvas-tool check --fixtures "$FIXTURES" --regen
swift run canvas-tool bakeoff --fixtures "$FIXTURES"

# Optional cards-only comparison. Copy first because each check writes canvas output.
STORYBOARD="${FIXTURES}-storyboard"
cp -R "$FIXTURES" "$STORYBOARD"
swift run canvas-tool check --fixtures "$STORYBOARD" --storyboard

# Optional diagnostic analysis of an already-disposable session copy.
# Replace the path and region with actual selected video-pixel bounds.
SESSION_COPY="/absolute/path/to/disposable-session-copy"
CANVAS_DEBUG=1 swift run canvas-tool analyze "$SESSION_COPY" --box 100,80,1000,600
```

## Explicitly unrun

Full macOS build; AVFoundation decoding; Vision estimates; Core Graphics composition; AVPlayer source seeks; SwiftUI interactions; user recordings; production performance; automatic temporal masks; automatic recovery; telemetry; observation/state schema; native composite export. No commit, push, or PR was created.
''')

(ROOT/'README.md').write_text('''# Canvas review package

A source-grounded review of `byronwall/context-recorder` at `76afc4faa24887408c275360132f0dd03384c94b`, prepared October 14, 2026 (America/Indiana/Indianapolis).

## Start here

- `canvas-review.md`: diagnosis, ten ranked changes, evidence, and canvas interaction proposals.
- `canvas-improvements.json`: exactly ten structured recommendations, VCI-01–VCI-10.
- `codex-next-steps.md`: file-level scope, proposed gates, and macOS command run sheet.
- `canvas-concepts.html`: self-contained light-mode interaction concept using synthetic source images. No server or network needed. This is not the native app.
- `sources.md`: primary sources, reading inventory, exact baseline, and evidence limits.
- `results/`: machine-readable measurements, source verification, assertions, and logs.
- `experiments/`: source-verified upstream excerpts, platform stubs, probes, and the exact synthetic inputs. `run.sh` reproduces the diagnostics using installed tools; it does not install dependencies.
- `manifest.json`: sizes and SHA-256 values for packaged files (excluding itself).

The ZIP excludes compiled build products and Python caches. No fonts, installed dependencies, personal videos, credentials, or repository working tree are included. The four verbatim upstream source files are identified in `results/source-verification.json`; they are source evidence, not authored fixes.

## What was executed

Actual Swift row matching, join verification, change gating, run patch planning, and segmentation ran with Linux raw-array/image-metadata stubs. The four algorithm source copies passed Git blob verification. Thirty-four synthetic pairs, ten sequences totaling 380 frames, and one 20-frame anchor ablation were evaluated. Two sequences passed through FFmpeg H.264 encoding/decoding. Independent OpenCV probes generated local phase-correlation and sparse-flow candidates. All 23 reproduction assertions passed, including assertions that reproduce failures.

## What that does not establish

No real user recording was supplied or fetched. No full macOS app, Apple decoder, Vision estimator, Core Graphics compositor, AVPlayer seek, or SwiftUI interaction was executed. Known-region crops and a known-transient skip are oracle tests, not automatic fixes. Motion candidates are not accepted truthful stitches. Synthetic pass/fail numbers do not estimate field accuracy.

The HTML demonstration has syntax/data checks, not a completed browser or usability test. Its atlas is a Python rendering of the clean Swift patch plan; its viewport positions come from synthetic fixture ground truth. The diagnosis and implementation proposals do not depend on that demonstration being adopted.

## Reproducibility

Exact environment versions and the input corpus are included. Synthetic regeneration uses a local DejaVu Sans font when present and otherwise Pillow's default; different fonts/tool versions can change the stress tests. Do not compare a regenerated corpus to these numbers without recording the environment. To inspect the exact executed inputs, use the included `.gray` arrays (8-bit row-major, dimensions in input JSON), PNG pair previews, and H.264 MP4 controls.

No repository files were edited and no PR was created. All implementation changes remain proposals for Codex review.
''')
print('[assembled] source ledger, 10 recommendations, handoff, README')
