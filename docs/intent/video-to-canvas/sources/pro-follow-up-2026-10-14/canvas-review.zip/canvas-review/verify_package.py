"""Check deliverables and build a manifest/ZIP; excludes derived compiled caches."""
from pathlib import Path
import ast,base64,hashlib,io,json,re,subprocess,zipfile
from html.parser import HTMLParser
from PIL import Image
ROOT=Path(__file__).resolve().parent
class Parse(HTMLParser):
    def __init__(self):
        super().__init__(); self.ids=[]; self.assets=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if 'id' in a:self.ids.append(a['id'])
        for k in ('src','href'):
            if k in a:self.assets.append(a[k])
checks=[]
def check(name,passed):
    checks.append({'name':name,'passed':bool(passed)})
    if not passed:raise AssertionError(name)
for p in ROOT.rglob('*.json'):
    if 'build' in p.relative_to(ROOT).parts:continue
    json.loads(p.read_text())
check('All JSON files parse',True)
recs=json.loads((ROOT/'canvas-improvements.json').read_text())
check('Exactly ten stable recommendation IDs', [r['id'] for r in recs]==[f'VCI-{i:02}' for i in range(1,11)])
for r in recs:
    check(f"{r['id']} has substantive fields", all(r.get(k) for k in ['title','problem','proposal','repositoryEvidence','cost','confidence','validation']))
source=json.loads((ROOT/'results/source-verification.json').read_text())
for f in source['files']:
    p=ROOT/'experiments/upstream'/Path(f['path']).name;b=p.read_bytes()
    check('Git blob verified: '+p.name,hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()==f['gitBlobSha'])
for p in ROOT.rglob('*.py'):
    ast.parse(p.read_text(),filename=str(p))
check('All Python source parses',True)
subprocess.run(['bash','-n',str(ROOT/'experiments/run.sh')],check=True)
check('Run sheet Bash syntax',True)
html=(ROOT/'canvas-concepts.html').read_text();parser=Parse();parser.feed(html)
check('Unique HTML IDs',len(parser.ids)==len(set(parser.ids)))
scripts=re.findall(r'<script(?:\s[^>]*)?>(.*?)</script>',html,re.S)
concept=json.loads(scripts[0])
subprocess.run(['node','--check'],input=scripts[1],text=True,check=True)
check('Concept JavaScript syntax',True)
refs=set(re.findall(r"\$\('([^']+)'\)",scripts[1]))
check('Referenced concept elements exist',refs.issubset(set(parser.ids)))
check('No external concept asset requests',not any(x.startswith(('http:','https:','//')) for x in parser.assets))
images=[]
for s in concept['scenes']:
    images.append(s['atlas']);images.extend(f['src'] for f in s['frames'])
images.extend([concept['edit']['before'],concept['edit']['after']])
for d in concept['diagnostics']:images.extend([d['before'],d['after']])
for u in images:
    with Image.open(io.BytesIO(base64.b64decode(u.split(',',1)[1]))) as img:img.verify()
check(f'Embedded concept PNG integrity ({len(images)} images)',True)
rep=json.loads((ROOT/'results/reproduction-checks.json').read_text())
check('Reproduction assertions recorded as 23/23',rep['passed']==rep['total']==23)
(ROOT/'results/artifact-checks.json').write_text(json.dumps({'kind':'artifact/source integrity, not product acceptance','checks':checks,'browserInteraction':'unrun','nativeUI':'unrun'},indent=2)+'\n')
def include(p):
    rel=p.relative_to(ROOT)
    return p.is_file() and p.name!='manifest.json' and 'build' not in rel.parts and '__pycache__' not in rel.parts
paths=sorted(p for p in ROOT.rglob('*') if include(p))
manifest={'kind':'canvas implementation review package','repository':'byronwall/context-recorder','commit':'76afc4faa24887408c275360132f0dd03384c94b','reviewDate':'2026-10-14','timezone':'America/Indiana/Indianapolis','excludes':['manifest.json (self)','compiled build products','Python caches'],'files':[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths]}
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
zip_path=ROOT.parent/'canvas-review.zip'
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in paths+[ROOT/'manifest.json']:z.write(p,Path(ROOT.name)/p.relative_to(ROOT))
with zipfile.ZipFile(zip_path) as z:
    check('ZIP integrity',z.testzip() is None)
    for f in manifest['files']:
        b=z.read('canvas-review/'+f['path'])
        assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256']
print(json.dumps({'files':len(paths)+1,'zipBytes':zip_path.stat().st_size,'zipMiB':round(zip_path.stat().st_size/(1<<20),2),'uncompressedMiB':round(sum(p.stat().st_size for p in paths)/(1<<20),2),'artifactChecks':len(checks),'allPassed':all(c['passed'] for c in checks)},indent=2))
